export default class Shortcut {

    static Keys = {
        A: "a",
        B: "b",
        C: "c",
        D: "d",
        E: "e",
        F: "f",
        G: "g",
        H: "h",
        I: "i",
        J: "j",
        K: "k",
        L: "l",
        M: "m",
        N: "n",
        O: "o",
        P: "p",
        Q: "q",
        R: "r",
        S: "s",
        T: "t",
        U: "u",
        V: "v",
        W: "w",
        X: "x",
        Y: "y",
        Z: "z",

        ENTER: "Enter",
        ESCAPE: "Escape",
        SPACE: " ",
        TAB: "Tab"
    };

    static Modifiers = {
        ALT: "altKey",
        CTRL: "ctrlKey",
        SHIFT: "shiftKey"
    };

    static setShortcut(keys) {
        return {
            keys: keys
        };
    }

    setShortcut(keys) {
        return Shortcut.setShortcut(keys);
    }
}